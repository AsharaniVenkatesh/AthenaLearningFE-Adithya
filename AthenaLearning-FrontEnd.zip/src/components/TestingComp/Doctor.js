import React from 'react';

function Doctor(props){
   
    return(
<div>
   <h1>Doctor Page</h1>
   <h2></h2>
</div>
    )
}

export default Doctor;