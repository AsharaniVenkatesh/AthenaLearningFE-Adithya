import React from 'react'

const DoctorDetails = (props) => {

    return(
        <div>
            <h1>{props.courseName}</h1>
        </div>
    )

}

export default DoctorDetails;