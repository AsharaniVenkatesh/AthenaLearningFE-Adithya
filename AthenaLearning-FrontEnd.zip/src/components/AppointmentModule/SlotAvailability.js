import React from 'react'
import ShowCalender from './ShowCalender'
import ShowDoctorsList from './ShowDoctorsList'

const SlotAvailability = () =>{

    return(
        <div>
<ShowDoctorsList/>
        </div>
    )
}

export default SlotAvailability