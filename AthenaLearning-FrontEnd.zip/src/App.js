import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import HomePage from './components/HomePage/HomePage';
import Login from './components/Login/Login';
import Courses from './components/Courses/Courses';
import CoursePage from './components/coursePage/CoursePage';
import ShowDoctorsList from './components/AppointmentModule/ShowDoctorsList';

import SlotAvailability from './components/AppointmentModule/SlotAvailability';
import ShowCalender from './components/AppointmentModule/ShowCalender';
import Testing1 from './components/TestingComp/Testing1';
import Testing2 from './components/TestingComp/Testing2';
import Doctor from './components/TestingComp/Doctor';


function App() {
  return (
    <>
      <Router>

        <Switch>
          <Route path="/" component={HomePage} exact />
          <Route path="/login" component={Login} />

          <Route path="/courses" component={Courses} />
          <Route path="/coursepage/:courseId" component={CoursePage} />
          <Route path="/showCalender" component={ShowCalender}/>
          <Route path="/showDoctorsList" component={ShowDoctorsList}/>
          <Route path="/slotAvailability" component={SlotAvailability}/>
          <Route path="/testing1" component={Testing1}/>
          <Route path="/tst2" component={Testing2}/>
          <Route path="/doctor" component={Doctor}/>
          <Route path="*" component={HomePage} />
        
        </Switch>
      </Router>


    </>
  );
}

export default App;
